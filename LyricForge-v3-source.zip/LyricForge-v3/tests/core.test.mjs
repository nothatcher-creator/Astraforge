import assert from 'node:assert/strict';
import {test} from 'node:test';
import {createProject,makeClip,evenlyTimeWords,retime,splitClip,mergeClips,setText,parseTime} from './.compiled/model.mjs';
import {parseLyrics,exportLyrics,detectStructure} from './.compiled/lyrics.mjs';
import {History} from './.compiled/history.mjs';
import {keyedStyle} from './.compiled/animation.mjs';
import {timeAtPosition,fitTimelineScale} from './.compiled/timeline-geometry.mjs';
test('phone and desktop timeline seeking agree after scrolling',()=>{
  for(const label of [110,174]) {
    const scale=52,scroll=418,time=12873;
    const pointer=label+time/1000*scale-scroll;
    assert.equal(timeAtPosition(pointer+scroll,label,scale,240000),time);
    assert.equal(timeAtPosition(label-1,label,scale,240000),0);
    assert.equal(timeAtPosition(1e9,label,scale,240000),240000);
  }
});
test('Fit shows the end of a long song on a narrow phone timeline',()=>{
  for(const [width,label] of [[320,110],[390,110],[1280,174]]) {
    const duration=600000,scale=fitTimelineScale(width,label,duration);
    assert.ok(label+duration/1000*scale<=width-23);
    assert.equal(timeAtPosition(width-24,label,scale,duration),duration);
  }
});
const sample=()=>{const c=makeClip('lyrics','lyrics',1000,5000,'This is a test');c.words=evenlyTimeWords(c.text,c.start,c.end);return c;};
test('timing uses exact milliseconds across import and text exports',()=>{for(const ext of ['lrc','srt','vtt']){const c=retime(sample(),1234,5678);const exported=exportLyrics([c],ext);const imported=parseLyrics(exported,ext,'lyrics',5678);assert.equal(imported[0].start,1234);assert.equal(imported[0].end,5678);assert.equal(imported[0].text,c.text);}});
test('retiming moves words and keyframes together',()=>{const c=sample();c.keyframes=[{id:'k',time:3000,property:'x',value:.5,easing:'linear'}];const n=retime(c,4000,12000);assert.deepEqual(n.words.map(w=>[w.start,w.end]),[[4000,6000],[6000,8000],[8000,10000],[10000,12000]]);assert.equal(n.keyframes[0].time,8000);assert.equal(c.start,1000);});
test('word correction preserves its detected timing',()=>{const c=sample();const next=setText(c,'This was a test');assert.equal(next.words[1].text,'was');assert.equal(next.words[1].start,c.words[1].start);});
test('split and merge preserve text and valid intervals',()=>{const parts=splitClip(sample(),3000);assert.equal(parts.length,2);assert.equal(parts[0].end,parts[1].start);assert.equal(parts.map(c=>c.text).join(' '),'This is a test');assert.equal(mergeClips(parts).text,'This is a test');for(const c of parts)for(const w of c.words){assert.ok(w.end>=w.start);assert.ok(w.start>=c.start&&w.end<=c.end);}});
test('LRC honors repeated timestamps, metadata, and offsets',()=>{const clips=parseLyrics('[ar:QA]\n[offset:-100]\n[00:01.234][00:02.345]Hello\n[00:04.000]World','lrc','t',5000);assert.deepEqual(clips.map(c=>c.start),[1134,2245,3900]);assert.equal(clips.length,3);});
test('subtitle parsers preserve multiline cues and ASS commas',()=>{const vtt='WEBVTT\n\ncue-a\n00:00:01.250 --> 00:00:03.700 align:start\nFirst line\nSecond line\n';assert.equal(parseLyrics(vtt,'vtt','t')[0].text,'First line\nSecond line');const ass='[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\nDialogue: 0,0:00:01.25,0:00:03.50,Default,,0,0,0,,Hello, world\\Nsecond';const c=parseLyrics(ass,'ass','t')[0];assert.equal(c.text,'Hello, world\nsecond');assert.equal(c.end,3500);});
test('history restores whole project and clears divergent redo',()=>{const h=new History(),p=createProject(),b={...p,name:'B'},c={...p,name:'C'};h.push(p);assert.equal(h.undo(b).name,p.name);assert.equal(h.redo(p).name,'B');h.push(b);assert.equal(h.undo(c).name,'B');h.push(b);assert.equal(h.future.length,0);});
test('keyframes interpolate relative to project timestamps',()=>{const p=createProject(),c=sample();c.keyframes=[{id:'a',property:'x',time:1000,value:.2,easing:'linear'},{id:'b',property:'x',time:5000,value:.8,easing:'linear'}];assert.equal(keyedStyle(p.lyricStyle,c,3000).x,.5);assert.equal(keyedStyle(p.lyricStyle,c,0).x,.2);assert.equal(keyedStyle(p.lyricStyle,c,6000).x,.8);});
test('structure estimates mark repetition and instrumental gaps',()=>{const p=createProject();p.clips=[sample(),{...sample(),id:'b',start:10000,end:14000}];const next=detectStructure(p);assert.ok(next.clips.every(c=>c.section==='Chorus'));assert.ok(next.sections.some(s=>s.name==='Instrumental'&&s.estimated));});

import {TapSynchronizer} from './.compiled/synchronization.mjs';
import {EditorStore} from './.compiled/store.mjs';
test('manual sync keeps lyric order when taps cross estimated starts',()=>{let p=createProject();p.duration=20000;p.clips=['First','Second','Third'].map((t,i)=>makeClip('lyrics',p.tracks[0].id,i*1000,(i+1)*1000,t));const ids=p.clips.map(c=>c.id),sync=new TapSynchronizer();let selected=[ids[0]];for(const [index,time] of [5000,8500,11000].entries()){const result=sync.tap(p,selected,time);assert.ok(result);p=result.project;assert.equal(p.clips.find(c=>c.id===ids[index]).start,time);selected=[result.nextId];}assert.deepEqual(p.clips.map(c=>c.end),[8500,11000,20000]);});
test('fresh manual lines have usable editable word timing',()=>{const c=makeClip('lyrics','t',123,3123,'New manual line');assert.equal(c.words.length,3);assert.deepEqual(c.words.map(w=>w.text),['New','manual','line']);assert.equal(c.words[0].start,123);});
test('timing offsets respect only editable selection',()=>{const s=new EditorStore();const p=createProject();p.tracks[1].locked=true;p.clips=[makeClip('lyrics',p.tracks[0].id,1000,2000,'Text'),makeClip('audio',p.tracks[1].id,0,2000)];s.setProject(p);s.select(p.clips.map(c=>c.id));s.offset(-500);assert.equal(s.project.clips[0].start,500);assert.equal(s.project.clips[1].start,0);s.undo();assert.equal(s.project.clips[0].start,1000);});
test('locked edits and empty offsets create no history entries',()=>{const s=new EditorStore();const p=createProject();p.tracks[0].locked=true;p.clips=[makeClip('lyrics',p.tracks[0].id,0,2000,'Locked')];s.setProject(p);s.patch(p.clips[0].id,{text:'changed'});s.offset(100);assert.equal(s.history.past.length,0);assert.equal(s.project.clips[0].text,'Locked');});
test('splits inside a detected word keep all word times in their clips',()=>{const c=makeClip('lyrics','t',0,4000,'One two three');c.words=[{text:'One',start:1000,end:1500},{text:'two',start:2000,end:2500},{text:'three',start:3000,end:3500}];for(const split of [10,1200,2000,3990])for(const part of splitClip(c,split))for(const w of part.words){assert.ok(w.start>=part.start&&w.end<=part.end);assert.ok(w.end>=w.start);}});
